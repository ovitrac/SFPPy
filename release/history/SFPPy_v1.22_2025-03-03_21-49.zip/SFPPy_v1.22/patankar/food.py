#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
===============================================================================
SFPPy Module: Food Layer
===============================================================================
Defines **food materials** for migration simulations. Models food as a **0D layer** with:
- **Mass transfer resistance (`h`)**
- **Partitioning (`k`)**
- **Contact time & temperature**

**Main Components:**
- **Base Class: `foodphysics`** (Stores all food-related parameters)
    - Defines mass transfer properties (`h`, `k`)
    - Implements property propagation (`food >> layer`)
- **Subclasses:**
    - `foodlayer`: General food layer model
    - `setoff`: Periodic boundary conditions (e.g., stacked packaging)
    - `nofood`: Impervious boundary (no mass transfer)
    - `realcontact` & `testcontact`: Standardized storage and testing conditions

**Integration with SFPPy Modules:**
- Works with `migration.py` as the **left-side boundary** for simulations.
- Can inherit properties from `layer.py` for **contact temperature propagation**.
- Used in `geometry.py` when defining food-contacting packaging.

Example:
```python
from patankar.food import foodlayer
medium = foodlayer(name="ethanol", contacttemperature=(40, "degC"))
```


@version: 1.22
@project: SFPPy - SafeFoodPackaging Portal in Python initiative
@author: INRAE\\olivier.vitrac@agroparistech.fr
@licence: MIT
@Date: 2023-01-25
@rev: 2025-03-03

"""

# Dependencies
import sys
import inspect
import textwrap
import numpy as np
from copy import deepcopy as duplicate

from patankar.layer import check_units, NoUnits, layer # to convert units to SI
from patankar.loadpubchem import migrant

__all__ = ['ambient', 'aqueous', 'boiling', 'check_units', 'chemicalaffinity', 'chilled', 'ethanol', 'ethanol50', 'fat', 'foodlayer', 'foodphysics', 'foodproperty', 'frozen', 'get_defined_init_params', 'help_food', 'hotfilled', 'intermediate', 'is_valid_classname', 'layer', 'liquid', 'list_food_classes', 'nofood', 'oven', 'pasteurization', 'perfectlymixed', 'realcontact', 'realfood', 'rolled', 'semisolid', 'setoff', 'simulant', 'solid', 'stacked', 'sterilization', 'tenax', 'testcontact', 'texture', 'water', 'wrap_text', 'yogurt']

__project__ = "SFPPy"
__author__ = "Olivier Vitrac"
__copyright__ = "Copyright 2022"
__credits__ = ["Olivier Vitrac"]
__license__ = "MIT"
__maintainer__ = "Olivier Vitrac"
__email__ = "olivier.vitrac@agroparistech.fr"
__version__ = "1.21"
#%% Private Properties and functions

# List of the default SI units used by physical quantity
parametersWithUnits = {"volume":"m**3",
                       "surfacearea":"m**2",
                       "density":"kg/m**3",
                       "contacttemperature":"degC",
                       "h":"m/s",
                       "k":NoUnits,  # user (preferred)
                       "k0":NoUnits, # alias (can be used after instantiation)
                       "CF0":NoUnits,
                       "contacttime":"s"
                       }
# corresponding protperty names                       }
paramaterNamesWithUnits = [p+"Units" for p in parametersWithUnits.keys()]

# List parameters not used with nofood, noPBC
parametersWithUnits_andfallback = [key for key in parametersWithUnits if key != "contacttime"]

LEVEL_ORDER = {"base": 0, "root": 1, "property":2, "contact":3, "user": 4}  # Priority order for sorting

def wrap_text(text, width=20):
    """Wraps text within a specified width and returns a list of wrapped lines."""
    if not isinstance(text, str):
        return [str(text)]
    return textwrap.wrap(text, width) or [""]  # Ensure at least one line

def get_defined_init_params(instance):
    """Returns which parameters from parametersWithUnits are defined in the instance."""
    return [param for param in parametersWithUnits.keys() if hasattr(instance, param)]

def is_valid_classname(name):
    """Returns True if class name is valid (not private/internal)."""
    return name.isidentifier() and not name.startswith("_")  # Exclude _10, __, etc.

def list_food_classes():
    """
    Lists all classes in the 'food' module with:
    - name and description
    - level (class attribute)
    - Inheritance details
    - Parameters from parametersWithUnits that are set in the instance
    """
    subclasses_info = []
    current_module = sys.modules[__name__]  # Reference to the food module

    for name, obj in inspect.getmembers(current_module, inspect.isclass):
        if obj.__module__ == current_module.__name__ and is_valid_classname(name):  # Ensure valid class name
            try:
                instance = obj()  # Try to instantiate
                init_params = get_defined_init_params(instance)
                level = getattr(obj, "level", "other")  # Default to "other" if no level is set

                class_info = {
                    "Class Name": wrap_text(name),
                    "Name": wrap_text(getattr(instance, "name", "N/A")),
                    "Description": wrap_text(getattr(instance, "description", "N/A")),
                    "Level": wrap_text(level),
                    "Inheritance": wrap_text(", ".join(base.__name__ for base in obj.__bases__)),
                    "Init Params": wrap_text(", ".join(init_params) if init_params else ""),
                    "Level Sorting": LEVEL_ORDER.get(level, 3)  # Used for sorting, not for table output
                }
                subclasses_info.append(class_info)
            except TypeError:
                class_info = {
                    "Class Name": wrap_text(name),
                    "Name": ["N/A"],
                    "Description": ["N/A"],
                    "Level": wrap_text(getattr(obj, "level", "other")),
                    "Inheritance": wrap_text(", ".join(base.__name__ for base in obj.__bases__)),
                    "Init Params": wrap_text("⚠️ Cannot instantiate"),
                    "Level Sorting": LEVEL_ORDER.get(getattr(obj, "level", "other"), 3)
                }
                subclasses_info.append(class_info)

    # **Sort first by level priority, then alphabetically within each level**
    subclasses_info.sort(key=lambda x: (x["Level Sorting"], x["Class Name"]))

    return subclasses_info

def help_food():
    """
    Prints all food-related classes with relevant attributes in a **formatted Markdown table**.
    """
    derived = list_food_classes()

    # Define table headers (excluding "Level Sorting" because it's only used for sorting)
    headers = ["Class Name", "Name", "Description", "Level", "Inheritance", "Init Params"]

    # Find the maximum number of lines in any wrapped column (excluding "Level Sorting")
    max_lines_per_row = [
        max(len(value) for key, value in row.items() if key != "Level Sorting")
        for row in derived
    ]

    # Convert dictionary entries to lists and ensure they all have the same number of lines
    formatted_rows = []
    for row, max_lines in zip(derived, max_lines_per_row):
        wrapped_row = {
            key: (value if isinstance(value, list) else [value]) + [""] * (max_lines - len(value))
            for key, value in row.items() if key != "Level Sorting"  # Exclude "Level Sorting"
        }
        for i in range(max_lines):  # Transpose wrapped lines into multiple rows
            formatted_rows.append([wrapped_row[key][i] for key in headers])

    # Compute column widths dynamically
    col_widths = [max(len(str(cell)) for cell in col) for col in zip(headers, *formatted_rows)]

    # Create a formatting row template
    row_format = "| " + " | ".join(f"{{:<{w}}}" for w in col_widths) + " |"

    # Print the table header
    print(row_format.format(*headers))
    print("|-" + "-|-".join("-" * w for w in col_widths) + "-|")

    # Print all table rows
    for row in formatted_rows:
        print(row_format.format(*row))


#%% Base physics class
# -------------------------------------------------------------------
# Base Class to convert class defaults to instance attributes
# -------------------------------------------------------------------
class foodphysics:
    """
    Base class that automatically assigns instance attributes from class defaults,
    except for the 'description' attribute.
    Check the physical meaning of quantities with units.

    Implemented methods include:
        - refresh() validates all quantities before a simulation
        - update(name="new name", description="new description",parameter1=value)
          assigns new values to physical parameters and attributes
        - getparam() returns physical parameters even if they undefined
    Available properties:
        PBC returns True in periodic boundary conditions are enforced (setoff)
        impervious returns True if impervious boundary condition is appled (no food)
    """

    # General descriptors
    description = "Root physics class used to implement food and mass transfer physics"  # Remains as class attribute
    name = "food physics"
    level = "base"

    # Low-level prediction properties (F=contact medium, i=solute/migrant)
    # these @properties are defined by foodlayer, they should be duplicated
    _lowLevelPredictionPropertyList = [
        "chemicalsubstance","simulant","polarityindex","ispolymer","issolid", # F: common with patankar.layer
        "physicalstate","chemicalclass", # phase F properties
        "substance","migrant","solute", # i properties with synonyms substance=migrant=solute
        # users use "k", but internally we use k0, keep _kmodel in the instance
        "k0","k0unit","kmodel","_compute_kmodel" # Henry-like coefficients returned as properties with possible user override with medium.k0model=None or a function
        ]

    # ------------------------------------------------------
    # Transfer rules for food1 >> food2 and food1 >> result
    # ------------------------------------------------------

    # Mapping of properties to their respective categories
    _list_categories = {
        "contacttemperature": "contact",
        "contacttime": "contact",
        "surfacearea": "geometry",
        "volume": "geometry",
        "substance": "substance",
        "medium": "medium"
    }

    # Rules for property transfer wtih >> or @ based on object type
    # ["property name"]["name of the destination class"][attr]
    #   - if onlyifinherited, only inherited values are transferred
    #   - if checkNmPy, the value will be transferred as a np.ndarray
    #   - name is the name of the property in the destination class (use "" to keep the same name)
    #   - prototype is the class itself (available only after instantiation, keep None here)
    _transferable_properties = {
        "contacttemperature": {
            "foodphysics": {
                "onlyifinherited": True,
                "checkNumPy": False,
                "as": "",
                "prototype": None,
            },
            "layer": {
                "onlyifinherited": False,
                "checkNumPy": True,
                "as": "T",
                "prototype": None
            }
        },
        "contacttime": {
            "foodphysics": {
                "onlyifinherited": True,
                "checkNumPy": True,
                "as": "",
                "prototype": None,
            },
            "SensPatankarResult": {
                "onlyifinherited": False,
                "checkNumPy": True,
                "as": "t",
                "prototype": None
            }
        },
        "surfacearea": {
            "foodphysics": {
                "onlyifinherited": False,
                "checkNumPy": False,
                "as": "surfacearea",
                "prototype": None
            }
        },
        "volume": {
            "foodphysics": {
                "onlyifinherited": False,
                "checkNumPy": True,
                "as": "",
                "prototype": None
            }
        },
        "substance": {
            "foodlayer": {
                "onlyifinherited": False,
                "checkNumPy": False,
                "as": "",
                "prototype": None,
            },
            "layer": {
                "onlyifinherited": False,
                "checkNumPy": False,
                "as": "",
                "prototype": None
            }
        },
        "medium": {
            "layer": {
                "onlyifinherited": False,
                "checkNumPy": False,
                "as": "",
                "prototype": None
            }
        },
    }


    def __init__(self, **kwargs):
        """general constructor"""

        # local import
        from patankar.migration import SensPatankarResult

        # numeric validator
        def numvalidator(key,value):
            if key in parametersWithUnits:          # the parameter is a physical quantity
                if isinstance(value,tuple):         # the supplied value as unit
                    value,_ = check_units(value)    # we convert to SI, we drop the units
                if not isinstance(value,np.ndarray):
                    value = np.array([value])       # we force NumPy class
            return value

        # Iterate through the MRO (excluding foodphysics and object)
        for cls in reversed(self.__class__.__mro__):
            if cls in (foodphysics, object):
                continue
            # For each attribute defined at the class level,
            # if it is not 'description', not callable, and not a dunder, set it as an instance attribute.
            for key, value in cls.__dict__.items(): # we loop on class attributes
                if key in ("description","level") or key in self._lowLevelPredictionPropertyList or key.startswith("__") or key.startswith("_") or callable(value):
                    continue
                if key not in kwargs:
                    setattr(self, key, numvalidator(key,value))
        # Now update/override with any keyword arguments provided at instantiation.
        for key, value in kwargs.items():
            value = numvalidator(key,value)
            if key not in paramaterNamesWithUnits: # we protect the values of units (they are SI, they cannot be changed)
                setattr(self, key, value)
        # we initialize the acknowlegment process for future property propagation
        self._hasbeeninherited = {}
        # we initialize _kmodel if _compute_kmodel exists
        if hasattr(self,"_compute_kmodel"):
            self._kmodel = "default" # do not initialize at self._compute_kmodel (default forces refresh)
        # we initialize the _simstate storing the last simulation result available
        self._simstate = None # simulation results
        self._inpstate = None # their inputs
        # For cooperative multiple inheritance, call the next __init__ if it exists.
        super().__init__()
        # Define actual class references to avoid circular dependency issues
        if self.__class__._transferable_properties["contacttemperature"]["foodphysics"]["prototype"] is None:
            self.__class__._transferable_properties["contacttemperature"]["foodphysics"]["prototype"] = foodphysics
            self.__class__._transferable_properties["contacttemperature"]["layer"]["prototype"] = layer
            self.__class__._transferable_properties["contacttime"]["foodphysics"]["prototype"] = foodphysics
            self.__class__._transferable_properties["contacttime"]["SensPatankarResult"]["prototype"] = SensPatankarResult
            self.__class__._transferable_properties["surfacearea"]["foodphysics"]["prototype"] = foodphysics
            self.__class__._transferable_properties["volume"]["foodphysics"]["prototype"] = foodphysics
            self.__class__._transferable_properties["substance"]["foodlayer"]["prototype"] = migrant
            self.__class__._transferable_properties["substance"]["layer"]["prototype"] = layer
            self.__class__._transferable_properties["medium"]["layer"]["prototype"] = layer

    # ------- [properties to access/modify simstate] --------
    @property
    def lastinput(self):
        """Getter for last layer input."""
        return self._inpstate

    @lastinput.setter
    def lastinput(self, value):
        """Setter for last layer input."""
        self._inpstate = value

    @property
    def lastsimulation(self):
        """Getter for last simulation results."""
        return self._simstate

    @lastsimulation.setter
    def lastsimulation(self, value):
        """Setter for last simulation results."""
        self._simstate = value

    @property
    def hassimulation(self):
        """Returns True if a simulation exists"""
        return self.lastsimulation is not None


    # ------- [inheritance registration mechanism] --------
    def acknowledge(self, what=None, category=None):
        """
        Register inherited properties under a given category.

        Parameters:
        -----------
        what : str or list of str or a set
            The properties or attributes that have been inherited.
        category : str
            The category under which the properties are grouped.

        Example:
        --------
        >>> b = B()
        >>> b.acknowledge(what="volume", category="geometry")
        >>> b.acknowledge(what=["surfacearea", "diameter"], category="geometry")
        >>> print(b._hasbeeninherited)
        {'geometry': {'volume', 'surfacearea', 'diameter'}}
        """
        if category is None or what is None:
            raise ValueError("Both 'what' and 'category' must be provided.")
        if isinstance(what, str):
            what = {what}  # Convert string to a set
        elif isinstance(what, list):
            what = set(what)  # Convert list to a set for uniqueness
        elif not isinstance(what,set):
            raise TypeError("'what' must be a string, a list, or a set of strings.")
        if category not in self._hasbeeninherited:
            self._hasbeeninherited[category] = set()
        self._hasbeeninherited[category].update(what)


    def refresh(self):
        """refresh all physcal paramaters after instantiation"""
        for key, value in self.__dict__.items():    # we loop on instance attributes
            if key in parametersWithUnits:          # the parameter is a physical quantity
                if isinstance(value,tuple):         # the supplied value as unit
                    value = check_units(value)[0]   # we convert to SI, we drop the units
                    setattr(self,key,value)
                if not isinstance(value,np.ndarray):
                    value = np.array([value])      # we force NumPy class
                    setattr(self,key,value)

    def update(self, **kwargs):
        """
        Update modifiable parameters of the foodphysics object.

        Modifiable Parameters:
            - name (str): New name for the object.
            - description (str): New description.
            - volume (float or tuple): Volume (can be tuple like (1, "L")).
            - surfacearea (float or tuple): Surface area (can be tuple like (1, "cm^2")).
            - density (float or tuple): Density (can be tuple like (1000, "kg/m^3")).
            - CF0 (float or tuple): Initial concentration in the food.
            - contacttime (float or tuple): Contact time (can be tuple like (1, "h")).
            - contacttemperature (float or tuple): Temperature (can be tuple like (25, "degC")).
            - h (float or tuple): Mass transfer coefficient (can be tuple like (1e-6,"m/s")).
            - k (float or tuple): Henry-like coefficient for the food (can be tuple like (1,"a.u.")).

        """
        if not kwargs:  # shortcut
            return self # for chaining
        def checkunits(value):
            """Helper function to convert physical quantities to SI."""
            if isinstance(value, tuple) and len(value) == 2:
                scale = check_units(value)[0]  # Convert to SI, drop unit
                return np.array([scale], dtype=float)  # Ensure NumPy array
            elif isinstance(value, (int, float, np.ndarray)):
                return np.array([value], dtype=float)  # Ensure NumPy array
            else:
                raise ValueError(f"Invalid value for physical quantity: {value}")
        # Update `name` and `description` if provided
        if "name" in kwargs:
            self.name = str(kwargs["name"])
        if "description" in kwargs:
            self.description = str(kwargs["description"])
        # Update physical properties
        for key in parametersWithUnits.keys():
            if key in kwargs:
                value = kwargs[key]
                setattr(self, key, checkunits(value))  # Ensure NumPy array in SI
        # Update medium, migrant (they accept aliases)
        lex = {
            "substance": ("substance", "migrant", "chemical", "solute"),
            "medium": ("medium", "simulant", "food", "contact"),
        }
        used_aliases = {}
        def get_value(canonical_key):
            """Find the correct alias in kwargs and return its value, or None if not found."""
            found_key = None
            for alias in lex.get(canonical_key, ()):  # Get aliases, default to empty tuple
                if alias in kwargs:
                    if alias in used_aliases:
                        raise ValueError(f"Alias '{alias}' is used for multiple canonical keys!")
                    found_key = alias
                    used_aliases[alias] = canonical_key
                    break  # Stop at the first match
            return kwargs.get(found_key, None)  # Return value if found, else None
        # Assign values only if found in kwargs
        new_substance = get_value("substance")
        new_medium = get_value("medium")
        if new_substance is not None: self.substance = new_substance
        if new_medium is not None:self.medium = new_medium
        # return
        return self  # Return self for method chaining if needed

    def get_param(self, key, default=None, acceptNone=True):
        """Retrieve instance attribute with a default fallback if enabled."""
        paramdefaultvalue = 1
        if isinstance(self,(setoff,nofood)):
            if key in parametersWithUnits_andfallback:
                value =  self.__dict__.get(key, paramdefaultvalue) if default is None else self.__dict__.get(key, default)
                if isinstance(value,np.ndarray):
                    value = value.item()
                if value is None and not acceptNone:
                    value = paramdefaultvalue if default is None else default
                return np.array([value])
            if key in paramaterNamesWithUnits:
                return self.__dict__.get(key, parametersWithUnits[key]) if default is None else self.__dict__.get(key, default)
        if key in parametersWithUnits:
            if hasattr(self, key):
                return getattr(self,key)
            else:
                raise KeyError(
                    f"Missing property: '{key}' in instance of class '{self.__class__.__name__}'.\n"
                    f"To define it, use one of the following methods:\n"
                    f"  - Direct assignment:   object.{key} = value\n"
                    f"  - Using update method: object.update({key}=value)\n"
                    f"Note: The value can also be provided as a tuple (value, 'unit')."
                )
        elif key in paramaterNamesWithUnits:
            return self.__dict__.get(key, paramaterNamesWithUnits[key]) if default is None else self.__dict__.get(key, default)
        raise KeyError(f'Use getattr("{key}") to retrieve the value of {key}')

    def __repr__(self):
        """Formatted string representation of the FOODlayer object."""
        # Refresh all definitions
        self.refresh()
        # Header with name and description
        repr_str = f'Food object "{self.name}" ({self.description}) with properties:\n'
        # Helper function to extract a numerical value safely
        def format_value(value):
            """Ensure the value is a float or a single-item NumPy array."""
            if isinstance(value, np.ndarray):
                return value.item() if value.size == 1 else value[0]  # Ensure scalar representation
            elif value is None:
                return value
            return float(value)
        # Collect defined properties and their formatted values
        properties = []
        excluded = ("k") if self.haskmodel else ("k0")
        for key, unit in parametersWithUnits.items():
            if hasattr(self, key) and key not in excluded:  # Include only defined parameters
                value = format_value(getattr(self, key))
                unit_str = self.get_param(f"{key}Units", unit)  # Retrieve unit safely
                if value is not None:
                    properties.append((key, f"{value:0.8g}", unit_str))

        # Sort properties alphabetically
        properties.sort(key=lambda x: x[0])

        # Determine max width for right-aligned names
        max_key_length = max(len(key) for key, _, _ in properties) if properties else 0
        # Construct formatted property list
        for key, value, unit_str in properties:
            repr_str += f"{key.rjust(max_key_length)}: {value} [{unit_str}]\n"
            if key == "k0":
                extra_info = f"{self._substance.k.__name__}(<{self.chemicalsubstance}>,{self._substance})"
                repr_str += f"{' ' * (max_key_length)}= {extra_info}\n"
        print(repr_str.strip())  # Print formatted output
        return str(self)  # Simplified representation for repr()



    def __str__(self):
        """Formatted string representation of the property"""
        simstr = ' [simulated]' if self.hassimulation else ""
        return f"<{self.__class__.__name__}: {self.name}>{simstr}"

    def copy(self,**kwargs):
        """Creates a deep copy of the current food instance."""
        return duplicate(self).update(**kwargs)


    @property
    def PBC(self):
        """
        Returns True if h is not defined or None
        This property is used to identified periodic boundary condition also called setoff mass transfer.

        """
        if not hasattr(self,"h"):
            return False # None
        htmp = getattr(self,"h")
        if isinstance(htmp,np.ndarray):
            htmp = htmp.item()
        return htmp is None

    @property
    def hassubstance(self):
        """Returns True if substance is defined (class migrant)"""
        if not hasattr(self, "_substance"):
            return False
        return isinstance(self._substance,migrant)



    # --------------------------------------------------------------------
    # For convenience, several operators have been overloaded
    #   medium >> packaging      # sets the volume and the surfacearea
    #   medium >> material       # propgates the contact temperature from the medium to the material
    #   sol = medium << material # simulate migration from the material to the medium
    # --------------------------------------------------------------------

    # method: medium._to(material) and its associated operator >>
    def _to(self, other = None):
        """
        Transfers inherited properties to another object based on predefined rules.

        Parameters:
        -----------
        other : object
            The recipient object that will receive the transferred properties.

        Notes:
        ------
        - Only properties listed in `_transferable_properties` are transferred.
        - A property can only be transferred if `other` matches the expected class.
        - The property may have a different name in `other` as defined in `as`.
        - If `onlyifinherited` is True, the property must have been inherited by `self`.
        - If `checkNumPy` is True, ensures NumPy array compatibility.
        - Updates `other`'s `_hasbeeninherited` tracking.
        """
        for prop, classes in self._transferable_properties.items():
            if prop not in self._list_categories:
                continue  # Skip properties not categorized

            category = self._list_categories[prop]

            for class_name, rules in classes.items():

                if not isinstance(other, rules["prototype"]):
                    continue  # Skip if other is not an instance of the expected prototype class

                if rules["onlyifinherited"] and category not in self._hasbeeninherited:
                    continue  # Skip if property must be inherited but is not

                if rules["onlyifinherited"] and prop not in self._hasbeeninherited[category]:
                    continue  # Skip if the specific property has not been inherited

                if not hasattr(self, prop):
                    continue  # Skip if the property does not exist on self

                # Determine the target attribute name in other
                target_attr = rules["as"] if rules["as"] else prop

                # Retrieve the property value
                value = getattr(self, prop)

                # Handle NumPy array check
                if rules["checkNumPy"] and hasattr(other, target_attr):
                    existing_value = getattr(other, target_attr)
                    if isinstance(existing_value, np.ndarray):
                        value = np.full(existing_value.shape, value)

                # Assign the value to other
                setattr(other, target_attr, value)

                # Register the transfer in other’s inheritance tracking
                other.acknowledge(what=target_attr, category=category)

                # to chain >>
                return other

    def __rshift__(self, other):
        """Overloads >> to propagate to other."""
        # inherit substance/migrant from other if self.migrant is None
        if isinstance(other,(layer,foodlayer)):
            if isinstance(self,foodlayer):
                if self.substance is None and other.substance is not None:
                    self.substance = other.substance
        return self._to(other) # propagates

    def __matmul__(self, other):
        """Overload @: equivalent to >> if other is a layer."""
        if not isinstance(other, layer):
            raise TypeError(f"Right operand must be a layer not a {type(other).__name__}")
        return self._to(other)

    # migration method
    def migration(self,material,**kwargs):
        """interface to simulation engine: senspantankar"""
        from patankar.migration import senspatankar
        self._to(material) # propagate contact conditions first
        return senspatankar(material,self,**kwargs)

    def contact(self,material,**kwargs):
        """alias to migration method"""
        return self.migration(self,material,**kwargs)

    @property
    def haskmodel(self):
        """Returns True if a kmodel has been defined"""
        if hasattr(self, "_compute_kmodel"):
            if self._compute_kmodel() is not None:
                return True
            elif callable(self.kmodel):
                return self.kmodel() is not None
        return False


# %% Root classes
# -------------------------------------------------------------------
# ROOT CLASSES
#   - The foodlayer class represents physically the food
#   - The chemicalaffinity class represents the polarity of the medium (with respect to the substance)
#   - The texture class represents the mass transfer reistance between the food and the material in contact
#   - The nofood class enforces an impervious boundary condition on the food side preventing any transfer.
#     This class is useful to simulate mass transfer within the packaging layer in the absence of food.
#   - The setoff class enforces periodic conditions such as when packaging are stacked together.
# -------------------------------------------------------------------

class foodlayer(foodphysics):
    """
    Foodlayer class is a generic class to define food as a 1D layer in a symmetric manner with layer class
    applicable to materials in contact.
    Since mass transfer are much faster in the food than in the materials in contact, food is represented
    as an almost 0D layer. Only a mass transfer resistance is applied at the food-material interface
    controlled by the mass transfer coefficient h. A Henry-like coefficient k controls the eventual
    partitioning of the substance between the food and the layer of the materials.

    Food are geometrically defined by their volume and surface area in contact with the material.

    Contact time (contacttime) and contact temperature (contacttemperature) are defined via foodlayer.

    """
    level = "root"
    description = "root food class"  # Remains as class attribute
    name = "generic food layer"
    # -----------------------------------------------------------------------------
    # Class attributes that can be overidden in instances.
    # Their default values are set in classes and overriden with similar
    # instance properties with @property.setter.
    # These values cannot be set during construction, but only after instantiation.
    # A common scale for polarity index for solvents is from 0 to 10:
    #     - 0-3: Non-polar solvents (e.g., hexane)
    #     - 4-6: Moderately polar solvents (e.g., acetone)
    #     - 7-10: Polar solvents (e.g., water)
    # -----------------------------------------------------------------------------
    # These properties are essential for model predictions, they cannot be customized
    # beyond the rules accepted by the model predictors (they are not metadata)
    # note: similar attributes exist for patanaker.layer objects (similar possible values)
    _physicalstate = "liquid"   # solid, liquid (default), gas, porous
    _chemicalclass = "other"    # polymer, other (default)
    _chemicalsubstance = None   # None (default), monomer for polymers
    _polarityindex = 0.0        # polarity index (roughly: 0=hexane, 10=water)
    # -----------------------------------------------------------------------------
    # Class attributes duplicated as instance parameters
    # -----------------------------------------------------------------------------
    volume,volumeUnits = check_units((1,"dm**3"))
    surfacearea,surfaceareaUnits = check_units((6,"dm**2"))
    density,densityUnits = check_units((1000,"kg/m**3"))
    CF0,CF0units = check_units((0,NoUnits))  # initial concentration (arbitrary units)
    contacttime, contacttime_units = check_units((10,"days"))
    contactemperature,contactemperatureUnits = check_units((40,"degC"),ExpectedUnits="degC") # temperature in °C
    _substance = None # substance container / similar construction in pantankar.layer = migrant
    _k0model = None
    # -----------------------------------------------------------------------------
    # Getter methods for class/instance properties: same definitions as in patankar.layer (mandatory)
    # medium properties
    # -----------------------------------------------------------------------------
    # PHASE PROPERTIES  (attention chemicalsubstance=F substance, substance=i substance)
    @property
    def physicalstate(self): return self._physicalstate
    @property
    def chemicalclass(self): return self._chemicalclass
    @property
    def chemicalsubstance(self): return self._chemicalsubstance
    @property
    def simulant(self): return self._chemicalsubstance # simulant is an alias of chemicalsubstance
    @property
    def polarityindex(self): return self._polarityindex
    @property
    def ispolymer(self): return self.physicalstate == "polymer"
    @property
    def issolid(self): return self.solid == "solid"
    # SUBSTANCE/SOLUTE/MIGRANT properties  (attention chemicalsubstance=F substance, substance=i substance)
    @property
    def substance(self): return self._substance # substance can be ambiguous
    @property
    def migrant(self): return self.substance    # synonym
    @property
    def solute(self): return self.substance     # synonym

    # -----------------------------------------------------------------------------
    # Setter methods for class/instance properties: same definitions as in patankar.layer (mandatory)
    # -----------------------------------------------------------------------------
    # PHASE PROPERTIES  (attention chemicalsubstance=F substance, substance=i substance)
    @physicalstate.setter
    def physicalstate(self,value):
        if value not in ("solid","liquid","gas","supercritical"):
            raise ValueError(f"physicalstate must be solid/liduid/gas/supercritical and not {value}")
        self._physicalstate = value
    @chemicalclass.setter
    def chemicalclass(self,value):
        if value not in ("polymer","other"):
            raise ValueError(f"chemicalclass must be polymer/oher and not {value}")
        self._chemicalclass= value
    @chemicalsubstance.setter
    def chemicalsubstance(self,value):
        if not isinstance(value,str):
            raise ValueError("chemicalsubtance must be str not a {type(value).__name__}")
        self._chemicalsubstance= value
    @simulant.setter
    def simulant(self,value):
        self.chemicalsubstance = value # simulant is an alias of chemicalcalsubstance
    @polarityindex.setter
    def polarityindex(self,value):
        if not isinstance(value,(float,int)):
            raise ValueError("polarity index must be float not a {type(value).__name__}")
        # rescaled to match predictions - standard scale [0,10.2] - predicted scale [0,7.12]
        return self._polarityindex * migrant("water").polarityindex/10.2
    # SUBSTANCE/SOLUTE/MIGRANT properties  (attention chemicalsubstance=F substance, substance=i substance)
    @substance.setter
    def substance(self,value):
        if isinstance(value,str):
            value = migrant(value)
        if not isinstance(value,migrant):
            raise TypeError(f"substance/migrant/solute must be a migrant not a {type(value).__name__}")
        self._substance = value
    @migrant.setter
    def migrant(self,value):
        self.substance = value
    @solute.setter
    def solute(self,value):
        self.substance = value
    # -----------------------------------------------------------------------------
    # Henry-like coefficient k and its alias k0 (internal use)
    # -----------------------------------------------------------------------------
    #   - k is the name of the Henry-like property for food (as set and seen by the user)
    #   - k0 is the property operated by migration
    #   - k0 = k except if kmodel (lambda function) does not returns None
    #   - kmodel returns None if _substance is not set (proper migrant)
    #   - kmodel = None will override any existing kmodel
    #   - kmodel must be intialized to "default" to refresh its definition with self
    # note: The implementation is almost symmetric with kmodel in patankar.layer.
    # The main difference are:
    #    - food classes are instantiated by foodphysics
    #    - k is used to store the value of k0 (not _k or _k0)
    # -----------------------------------------------------------------------------
    # layer substance (of class migrant or None)
    # k0 and k0units (k and kunits are user inputs)
    @property
    def k0(self):
        ktmp = None
        if self.kmodel == "default": # default behavior
            ktmp = self._compute_kmodel()
        elif callable(self.kmodel): # user override (not the default function)
            ktmp = self.kmodel()
        if ktmp:
            return np.full_like(self.k, ktmp,dtype=np.float64)
        return self.k
    @k0.setter
    def k0(self,value):
        if not isinstance(value,(int,float,np.ndarray)):
            TypeError("k0 must be int, float or np.ndarray")
        if isinstance(self.k,int): self.k = float(self.k)
        self.k = np.full_like(self.k,value,dtype=np.float64)
    @property
    def kmodel(self):
        return self._kmodel
    @kmodel.setter
    def kmodel(self,value):
        if value is None or callable(value):
            self._kmodel = value
        else:
            raise ValueError("kmodel must be None or a callable function")
    @property
    def _compute_kmodel(self):
        """Return a callable function that evaluates k with updated parameters."""
        if not isinstance(self._substance,migrant) or self._substance.keval() is None or self.chemicalsubstance is None:
            return lambda **kwargs: None  # Return a function that always returns None
        template = self._substance.ktemplate.copy()
        # add solute (i) properties: Pi and Vi have been set by loadpubchem already
        template.update(ispolymer = False)
        def func(**kwargs):
            if self.chemicalsubstance:
                simulant = migrant(self.chemicalsubstance)
                template.update(Pk = simulant.polarityindex,
                                Vk = simulant.molarvolumeMiller)
                k = self._substance.k.evaluate(**dict(template, **kwargs))
                return k
            else:
                self.k
        return func # we return a callable function not a value


class texture(foodphysics):
    """Parent food texture class"""
    description = "default class texture"
    name = "undefined"
    level = "root"
    h = 1e-3

class chemicalaffinity(foodphysics):
    """Parent chemical affinity class"""
    description = "default chemical affinity"
    name = "undefined"
    level = "root"
    k = 1.0

class nofood(foodphysics):
    """Impervious boundary condition"""
    description = "impervious boundary condition"
    name = "undefined"
    level = "root"
    h = 0

class setoff(foodphysics):
    """periodic boundary conditions"""
    description = "periodic boundary conditions"
    name = "setoff"
    level = "root"
    h = None

class realcontact(foodphysics):
    """real contact conditions"""
    description = "real storage conditions"
    name = "contact conditions"
    level = "root"
    [contacttime,contacttimeUnits] = check_units((200,"days"))
    [contacttemperature,contacttemperatureUnits] = check_units((25,"degC"))

class testcontact(foodphysics):
    """conditions of migration testing"""
    description = "migration testing conditions"
    name = "migration testing"
    level = "root"
    [contacttime,contacttimeUnits] = check_units((10,"days"))
    [contacttemperature,contacttemperatureUnits] = check_units((40,"degC"))

# %% Property classes
# -------------------------------------------------------------------
# SECOND LEVEL CLASSES
# This classes are used as keyword to define new food with a combination of properties.
# -------------------------------------------------------------------

# Food/chemical properties
class foodproperty(foodlayer):
    """Class wrapper of food properties"""
    level="property"

class realfood(foodproperty):
    """Core real food class (second level)"""
    description = "real food class"

class simulant(foodproperty):
    """Core food simulant class (second level)"""
    name = "generic food simulant"
    description = "food simulant"

class solid(foodproperty):
    """Solid food texture"""
    _physicalstate = "solid"    # it will be enforced if solid is defined first (see obj.mro())
    name = "solid food"
    description = "solid food products"
    [h,hUnits] = check_units((1e-8,"m/s"))

class semisolid(texture):
    """Semi-solid food texture"""
    name = "solid food"
    description = "solid food products"
    [h,hUnits] = check_units((1e-7,"m/s"))

class liquid(texture):
    """Liquid food texture"""
    name = "liquid food"
    description = "liquid food products"
    [h,hUnits] = check_units((1e-6,"m/s"))

class perfectlymixed(texture):
    """Perfectly mixed liquid (texture)"""
    name = "perfectly mixed liquid"
    description = "maximize mixing, minimize the mass transfer boundary layer"
    [h,hUnits] = check_units((1e-4,"m/s"))

class fat(chemicalaffinity):
    """Fat contact"""
    name = "fat contact"
    description = "maximize mass transfer"
    [k,kUnits] = check_units((1,NoUnits))

class aqueous(chemicalaffinity):
    """Aqueous food contact"""
    name = "aqueous contact"
    description = "minimize mass transfer"
    [k,kUnits] = check_units((1000,NoUnits))

class intermediate(chemicalaffinity):
    """Intermediate chemical affinity"""
    name = "intermediate"
    description = "intermediate chemical affinity"
    [k,kUnits] = check_units((10,NoUnits))

# Contact conditions

class frozen(realcontact):
    """real contact conditions"""
    description = "freezing storage conditions"
    name = "frrozen"
    level = "contact"
    [contacttime,contacttimeUnits] = check_units((6,"months"))
    [contacttemperature,contacttemperatureUnits] = check_units((-20,"degC"))

class chilled(realcontact):
    """real contact conditions"""
    description = "ambient storage conditions"
    name = "ambient"
    level = "contact"
    [contacttime,contacttimeUnits] = check_units((30,"days"))
    [contacttemperature,contacttemperatureUnits] = check_units((4,"degC"))

class ambient(realcontact):
    """real contact conditions"""
    description = "ambient storage conditions"
    name = "ambient"
    level = "contact"
    [contacttime,contacttimeUnits] = check_units((200,"days"))
    [contacttemperature,contacttemperatureUnits] = check_units((25,"degC"))

class transportation(realcontact):
    """hot transportation contact conditions"""
    description = "hot transportation storage conditions"
    name = "hot transportation"
    level = "contact"
    [contacttime,contacttimeUnits] = check_units((1,"month"))
    [contacttemperature,contacttemperatureUnits] = check_units((40,"degC"))

class hotambient(realcontact):
    """real contact conditions"""
    description = "hot ambient storage conditions"
    name = "hot ambient"
    level = "contact"
    [contacttime,contacttimeUnits] = check_units((2,"months"))
    [contacttemperature,contacttemperatureUnits] = check_units((40,"degC"))

class hotfilled(realcontact):
    """real contact conditions"""
    description = "hot-filling conditions"
    name = "hotfilled"
    level = "contact"
    [contacttime,contacttimeUnits] = check_units((20,"min"))
    [contacttemperature,contacttemperatureUnits] = check_units((80,"degC"))

class microwave(realcontact):
    """real contact conditions"""
    description = "microwave-oven conditions"
    name = "microwave"
    level = "contact"
    [contacttime,contacttimeUnits] = check_units((10,"min"))
    [contacttemperature,contacttemperatureUnits] = check_units((100,"degC"))

class boiling(realcontact):
    """real contact conditions"""
    description = "boiling conditions"
    name = "boiling"
    level = "contact"
    [contacttime,contacttimeUnits] = check_units((30,"min"))
    [contacttemperature,contacttemperatureUnits] = check_units((100,"degC"))

class pasteurization(realcontact):
    """real contact conditions"""
    description = "pasteurization conditions"
    name = "pasteurization"
    level = "contact"
    [contacttime,contacttimeUnits] = check_units((20,"min"))
    [contacttemperature,contacttemperatureUnits] = check_units((100,"degC"))

class sterilization(realcontact):
    """real contact conditions"""
    description = "sterilization conditions"
    name = "sterilization"
    level = "contact"
    [contacttime,contacttimeUnits] = check_units((20,"min"))
    [contacttemperature,contacttemperatureUnits] = check_units((121,"degC"))

class panfrying(realcontact):
    """real contact conditions"""
    description = "panfrying conditions"
    name = "panfrying"
    level = "contact"
    [contacttime,contacttimeUnits] = check_units((20,"min"))
    [contacttemperature,contacttemperatureUnits] = check_units((120,"degC"))


class frying(realcontact):
    """real contact conditions"""
    description = "frying conditions"
    name = "frying"
    level = "contact"
    [contacttime,contacttimeUnits] = check_units((10,"min"))
    [contacttemperature,contacttemperatureUnits] = check_units((160,"degC"))

class oven(realcontact):
    """real contact conditions"""
    description = "oven conditions"
    name = "oven"
    level = "contact"
    [contacttime,contacttimeUnits] = check_units((1,"hour"))
    [contacttemperature,contacttemperatureUnits] = check_units((180,"degC"))

class hotoven(realcontact):
    """real contact conditions"""
    description = "hot oven conditions"
    name = "hot oven"
    level = "contact"
    [contacttime,contacttimeUnits] = check_units((30,"min"))
    [contacttemperature,contacttemperatureUnits] = check_units((230,"degC"))


# %% End-User classes
# -------------------------------------------------------------------
# THIRD LEVEL CLASSES
# Theses classes correspond to real cases and can be hybridized to
# derive new classes, for instance, for a specific brand of yoghurt.
# -------------------------------------------------------------------
class stacked(setoff):
    """stacked storage"""
    name = "stacked"
    description = "storage in stacks"
    level = "user"

class rolled(setoff):
    """rolled storage"""
    name = "rolled"
    description = "storage in rolls"
    level = "user"

class isooctane(simulant, perfectlymixed, fat):
    """Isoactane food simulant"""
    _chemicalsubstance = "isooctane"
    _polarityindex = 1.0 # Very non-polar hydrocarbon. Dielectric constant ~1.9.
    name = "isooctane"
    description = "isooctane food simulant"
    level = "user"

class oiliveoil(simulant, perfectlymixed, fat):
    """Isoactane food simulant"""
    _chemicalsubstance = "methyl stearate"
    _polarityindex = 1.0 # Primarily triacylglycerides; still quite non-polar, though it contains some polar headgroups (the glycerol backbone).
    name = "olive oil"
    description = "olive oil food simulant"
    level = "user"
class oil(oiliveoil): pass # synonym of oliveoil

class ethanol(simulant, perfectlymixed, fat):
    """Ethanol food simulant"""
    _chemicalsubstance = "ethanol"
    _polarityindex = 5.0 # Polar protic solvent; dielectric constant ~24.5. Lower polarity than methanol.
    name = "ethanol"
    description = "ethanol = from pure ethanol down to ethanol 95%"
    level = "user"
class ethanol95(ethanol): pass # synonym of ethanol

class ethanol50(simulant, perfectlymixed, intermediate):
    """Ethanol 50% food simulant"""
    _chemicalsubstance = "ethanol"
    _polarityindex = 7.0 # Intermediate polarity between ethanol and water.
    name = "ethanol 50"
    description = "ethanol 50, food simulant of dairy products"
    level = "user"

class acetonitrile(simulant, perfectlymixed, aqueous):
    """Acetonitrile food simulant"""
    _chemicalsubstance = "acetonitrile"
    _polarityindex = 6.8 # Polar aprotic solvent; dielectric constant ~36. Comparable to methanol in some polarity rankings.
    name = "acetonitrile"
    description = "acetonitrile"
    level = "user"

class methanol(simulant, perfectlymixed, aqueous):
    """Methanol food simulant"""
    _chemicalsubstance = "methanol"
    _polarityindex = 8.1 # Polar protic, dielectric constant ~33. Highly capable of hydrogen bonding, but still less so than water.
    name = "methanol"
    description = "methanol"
    level = "user"

class water(simulant, perfectlymixed, aqueous):
    """Water food simulant"""
    _chemicalsubstance = "water"
    _polarityindex = 10.2
    name = "water"
    description = "water food simulant"
    level = "user"

class water3aceticacid(simulant, perfectlymixed, aqueous):
    """Water food simulant"""
    _chemicalsubstance = "water"
    _polarityindex = 10.0 # Essentially still dominated by water’s polarity; 3% acetic acid does not drastically lower overall polarity.
    name = "water 3% acetic acid"
    description = "water 3% acetic acid - simulant for acidic aqueous foods"
    level = "user"

class tenax(simulant, solid, fat):
    """Tenax(r) food simulant"""
    _physicalstate = "porous"    # it will be enforced if tenax is defined first (see obj.mro())
    name = "Tenax"
    description = "simulant of dry food products"
    level = "user"

class yogurt(realfood, semisolid, ethanol50):
    """Yogurt as an example of real food"""
    description = "yogurt"
    level = "user"
    [k,kUnits] = check_units((1,NoUnits))
    volume,volumeUnits = check_units((125,"mL"))

    # def __init__(self, name="no brand", volume=None, **kwargs):
    #     # Prepare a parameters dict: if a value is provided (e.g. volume), use it;
    #     # otherwise, the default (from class) is used.
    #     params = {}
    #     if volume is not None:
    #         params['volume'] = volume
    #     params['name'] = name
    #     params.update(kwargs)
    #     super().__init__(**params)

# -------------------------------------------------------------------
# Example usage (for debugging)
# -------------------------------------------------------------------
if __name__ == '__main__':
    F = foodlayer()
    E95 = ethanol()
    Y = yogurt()
    YF = yogurt(name="danone", volume=(150,"mL"))
    YF.description = "yogurt with fruits"  # You can still update the description on the instance if needed

    print("\n",repr(F),"\n"*2)
    print("\n",repr(E95),"\n"*2)
    print("\n",repr(Y),"\n"*2)
    print("\n",repr(YF),"\n"*2)

    # How to define a new food easily:
    class sandwich(realfood, solid, fat):
        name = "sandwich"
    S = sandwich()
    print("\n", repr(S))

    help_food()
